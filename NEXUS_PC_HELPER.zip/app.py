import tkinter as tk
from tkinter import messagebox
import os, platform, subprocess, shutil
try:
    import psutil
except ImportError:
    psutil = None

BG="#0a0f14"; PANEL="#101820"; TEXT="#f0f5f9"; MUTED="#8fa3b5"; CYAN="#3ddcff"; GREEN="#55e68a"; BUTTON="#16232d"

def ask_permission(action):
    return messagebox.askyesno("NEXUS Permission", f"NEXUS wants to:\n\n{action}\n\nAllow this?")

def gb(n): return round(n/(1024**3),1)

class App:
    def __init__(self, root):
        self.root=root
        root.title("NEXUS PC Helper")
        root.geometry("760x560")
        root.configure(bg=BG)
        tk.Label(root,text="NEXUS PC HELPER",font=("Segoe UI",22,"bold"),fg=CYAN,bg=BG).pack(pady=(20,4))
        tk.Label(root,text="Simple Windows troubleshooting and system tools",font=("Segoe UI",10),fg=MUTED,bg=BG).pack(pady=(0,18))
        self.info=tk.Text(root,height=12,bg=PANEL,fg=TEXT,relief="flat",font=("Consolas",11),padx=14,pady=14)
        self.info.pack(fill="x",padx=24)
        self.info.config(state="disabled")
        f=tk.Frame(root,bg=BG); f.pack(fill="both",expand=True,padx=24,pady=20)
        items=[("Refresh PC Info",self.refresh),("Open Task Manager",self.taskmgr),("Open Storage Settings",self.storage),("Open Temp Folder",self.temp),("Open Windows Update",self.update),("Open Device Manager",self.devices)]
        for i,(name,cmd) in enumerate(items):
            b=tk.Button(f,text=name,command=cmd,bg=BUTTON,fg=TEXT,relief="flat",font=("Segoe UI",11,"bold"),padx=12,pady=14)
            b.grid(row=i//2,column=i%2,sticky="nsew",padx=6,pady=6)
        for c in range(2): f.grid_columnconfigure(c,weight=1)
        for r in range(3): f.grid_rowconfigure(r,weight=1)
        tk.Label(root,text="NEXUS does not delete files automatically. Actions require permission first.",fg=GREEN,bg=BG,font=("Segoe UI",9)).pack(pady=(0,14))
        self.refresh()

    def refresh(self):
        lines=[f"Computer: {platform.node()}",f"Windows: {platform.platform()}",f"CPU: {platform.processor() or 'Unknown'}"]
        if psutil:
            ram=psutil.virtual_memory()
            lines += [f"RAM: {gb(ram.total)} GB total",f"RAM usage: {ram.percent}%",f"CPU usage: {psutil.cpu_percent(interval=0.3)}%"]
        try:
            total,used,free=shutil.disk_usage("C:\\")
            lines += [f"C: drive total: {gb(total)} GB",f"C: drive free: {gb(free)} GB"]
        except Exception:
            pass
        self.info.config(state="normal"); self.info.delete("1.0","end"); self.info.insert("1.0","\n".join(lines)); self.info.config(state="disabled")

    def taskmgr(self):
        if ask_permission("Open Windows Task Manager"): subprocess.Popen(["taskmgr.exe"])
    def storage(self):
        if ask_permission("Open Windows Storage Settings"): os.startfile("ms-settings:storagesense")
    def temp(self):
        if ask_permission("Open your temporary files folder"):
            p=os.environ.get("TEMP")
            if p and os.path.isdir(p): os.startfile(p)
    def update(self):
        if ask_permission("Open Windows Update settings"): os.startfile("ms-settings:windowsupdate")
    def devices(self):
        if ask_permission("Open Windows Device Manager"): subprocess.Popen(["devmgmt.msc"],shell=True)

if __name__=="__main__":
    r=tk.Tk(); App(r); r.mainloop()
